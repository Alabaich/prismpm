<?php return array('dependencies' => array(), 'version' => '82308f689545f2c86a6d');
